
public class UserNode {
	User element;
	UserNode next;
	
	public UserNode(User element) {
		this.element = element;
	}
}
