
public class LinkedListFriends {
	int size;
	UserNode head = null;
	UserNode tail = null;
	
	public void addFirst(User element) {
		UserNode newNode = new UserNode(element);
		newNode.next = head;
		head = newNode;
		size++;
		if (tail == null)
			tail = head;
	}
	
	public void addLast(User element) {
		UserNode newNode = new UserNode(element);
		if (head == null) { // empty linked list
			head = tail = newNode;
		} else {
			tail.next = newNode;
			tail = tail.next;
			size++;
		}
	}

	public void deleteFirst() {
		if (head == null) {
			System.out.println("Empty list. Cannot delete");
		}
		if (head == tail)
			head = tail = null;
		head = head.next;
		size--;
	}

	public void deleteLast() {
		if (tail == null) {
			System.out.println("Empty list. Cannot delete");
		}
		UserNode temp = head;
		while (temp.next != tail)
			temp = temp.next;
		tail = temp;
		temp.next = null;
		size--;
	}

	public void add(User element, int index) {
		if (index < 0 || index > size)
			System.out.println("Invalid index");
		else if (index == 0)
			addFirst(element);
		else if (index == size)
			addLast(element);
		else {
			UserNode newNode = new UserNode(element);
			UserNode temp = head;
			for (int i = 0; i < index - 1; i++)
				temp = temp.next;
			newNode.next = temp.next;
			temp.next = newNode;
			size++;
		}
	}

	public void delete(int index) {
		if (index >= size)
			System.out.println("Invalid index");
		else if (index == 0)
			deleteFirst();
		else if (index == size - 1)
			deleteLast();
		else {
			UserNode temp = head;
			for (int i = 0; i < index - 1; i++) {
				temp = temp.next;
			}
			UserNode current = temp.next;
			temp.next = current.next;
			size--;
		}
	}
	
	public User get(int index) {
		UserNode temp = head;
		for (int i = 0; i < index; i++) {
			temp = temp.next;
		}
		return temp.element;
	}
		
	public void displayList() {
		UserNode temp = head;
		while (temp != null) {
			System.out.println(temp.element);
			temp = temp.next;
		}
	}

	public int getIndex(String username) {
		UserNode temp = head;
		for (int i = 0; i < size; i++) {
			if(temp.element.name.equals(username))
				return temp.element.ID;
			temp = temp.next;
		}
		return -1;
	}
}
