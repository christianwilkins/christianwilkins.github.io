
public class Node {
	int element;
	Node next;
	
	public Node(int element) {
		this.element = element;
	}
}
