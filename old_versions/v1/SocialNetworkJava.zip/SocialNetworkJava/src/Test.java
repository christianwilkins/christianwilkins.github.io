import java.io.*;
import java.util.*;

public class Test {

	public static void main(String[] args) throws Exception {
		LinkedListFriends userData = generateUserData("UserData.txt");
		LinkedList[] edges = generateFriendList(userData.size, "FriendsData.txt");
		int[][] am = generateAdjacencyMatrix(edges);
		searchFriends(userData, am);
	}

	private static void searchFriends(LinkedListFriends userData, int[][] am) {
		System.out.println("Enter the username:");
		Scanner kin = new Scanner(System.in);
		String username = kin.next();
		int index = userData.getIndex(username);
		// System.out.println(index +"\t"+userData.get(index));
		if(index>=0) {
			System.out.println("Friends of " + username + ":");
			System.out.println("--------------------");
			System.out.println("Name\tEmail");
			System.out.println("--------------------");
			for (int x = 0; x < am.length; x++) {
				if (isFriend(index, x, am))
					System.out.println(userData.get(x));
			}
		} else {
			System.out.println("Not a valid username");
		}
		
	}

	private static boolean isFriend(int id1, int id2, int[][] am) {
		if (am[id1][id2] == 1) {
			return true;
		} else
			return false;
	}

	private static LinkedList[] generateFriendList(int size, String string) throws FileNotFoundException {
		LinkedList[] edges = new LinkedList[size+1];
		for (int x = 0; x < size+1; x++) {
			edges[x] = new LinkedList();
		}
		FileReader file = new FileReader(string);
		Scanner input = new Scanner(file);
		String title = input.nextLine();
//		int[][] nums = new int[6][2];
//		int ct = 0;
//		while (input.hasNext()) {
//			int one = input.nextInt();
//			int two = input.nextInt();
//			nums[ct][0] = one;
//			nums[ct][1] = two;
//			ct++;
//		}
//		for(int x = 0; x<6;x++) {
//			edges[nums[x][0]].addLast(nums[x][1]);
//		}
		edges[0].addLast(1);
		edges[0].addLast(2);
		edges[1].addLast(0);
		edges[1].addLast(3);
		edges[2].addLast(0);
		edges[3].addLast(1);
		return edges;
	}

	public static int[][] generateAdjacencyMatrix(LinkedList[] edges) {
		int[][] adjacencyMatrix = new int[edges.length][edges.length];
		for (int i = 0; i < edges.length; i++)
			for (int j = 0; j <= edges[i].size; j++) {
				adjacencyMatrix[i][edges[i].get(j)] = 1;
				adjacencyMatrix[edges[i].get(j)][i] = 1;
			}
		return adjacencyMatrix;
	}

	private static LinkedListFriends generateUserData(String string) throws FileNotFoundException {
		LinkedListFriends temp = new LinkedListFriends();
		FileReader file = new FileReader(string);
		Scanner input = new Scanner(file);
		while (input.hasNext()) {
			int num = input.nextInt();
			String name = input.next();
			String email = input.next();
			temp.addLast(new User(num, name, email));
		}
		return temp;
	}

}