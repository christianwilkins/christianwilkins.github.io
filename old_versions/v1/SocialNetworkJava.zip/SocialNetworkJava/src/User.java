
public class User {
	int ID;
	String name;
	String email;

	User() {

	}

	User(int i, String n, String e) {
		ID = i;
		name = n;
		email = e;
	}
	
	public String toString() {
		return name +"\t"+email;
	}
}
