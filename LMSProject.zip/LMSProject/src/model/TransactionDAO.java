package model;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;

public class TransactionDAO {

    Connection connection;
    public int rows;

    public TransactionDAO(String s) throws SQLException {
        String url = s;
        connection = DriverManager.getConnection(url);
    }

    public void insertTransaction(Transaction s) throws SQLException {
        PreparedStatement ps = connection.prepareStatement("INSERT INTO libtransactions VALUES(?,?,?,?)");
        ps.setInt(1, s.getBookID());
        ps.setInt(2, s.getUserID());
        ps.setDate(3, Date.valueOf(s.getIssueDate()));
        ps.setBoolean(4, s.isStatus());

        ps.executeUpdate();
    }

    public void updateTransaction(Transaction s) throws SQLException {
        PreparedStatement ps = connection.prepareStatement("UPDATE libtransactions SET status=? WHERE bookID=? AND userID=? AND issueDATE=?");
        ps.setInt(2, s.getBookID());
        ps.setInt(3, s.getUserID());
        ps.setDate(4, Date.valueOf(s.getIssueDate()));
        ps.setBoolean(1, s.isStatus());

        ps.executeUpdate();

    }

    public void deleteTransaction(Transaction s) throws SQLException {
        PreparedStatement ps = connection.prepareStatement("DELETE FROM libtransactions WHERE bookID=? AND userID=? AND issueDATE=?");
        ps.setInt(1, s.getBookID());
        ps.setInt(2, s.getUserID());
        ps.setDate(3, Date.valueOf(s.getIssueDate()));

        ps.executeUpdate();
    }


    public ArrayList<Transaction> getTransactions() throws SQLException {
        PreparedStatement ps = connection.prepareStatement("SELECT * FROM libtransactions");
        ResultSet rs = ps.executeQuery();
        ArrayList<Transaction> Transactions = new ArrayList<>();
        while (rs.next()) {
            Transaction temp = new Transaction(
                    rs.getInt(1),
                    rs.getInt(2),
                    rs.getDate(3).toLocalDate(),
                    rs.getBoolean(4)
            );
            Transactions.add(temp);

        }
        return Transactions;

    }

    public ArrayList<Transaction> getTransactionsByActive() throws SQLException {
        ArrayList<Transaction> Transactions = getTransactions();
        ArrayList<Transaction> temp = new ArrayList<>();
        for (Transaction u : Transactions) {
            if (u.isStatus()) {
                temp.add(u);
            }
        }
        return temp;
    }

    public Transaction getTransactionByBook(int id) throws SQLException {
        ArrayList<Transaction> Transactions = getTransactions();
        for (Transaction u : Transactions) {
            if (u.getBookID() == id) {
                return u;
            }
        }
        return null;
    }

    public Transaction getTransactionByUser(int id) throws SQLException {
        ArrayList<Transaction> Transactions = getTransactions();
        for (Transaction u : Transactions) {
            if (u.getUserID() == id) {
                return u;
            }
        }
        return null;
    }

}

