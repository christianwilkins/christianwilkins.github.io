package model;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;

public class UserDAO {

    Connection connection;
    public int rows;

    public UserDAO(String s) throws SQLException {
        String url = s;
        connection = DriverManager.getConnection(url);
    }

    public void insertUser(User s) throws SQLException {
        PreparedStatement ps = connection.prepareStatement("INSERT INTO users(name, email, address, dateOfBirth, isStudent) VALUES(?,?,?,?,?)");
        ps.setString(1, s.getName());
        ps.setString(2, s.getEmail());
        ps.setString(3, s.getAddress());
        ps.setDate(4, Date.valueOf(s.getDateOfBirth()));
        ps.setBoolean(5, s.getStudent());

        ps.executeUpdate();
    }

    public void updateUser(User s) throws SQLException {
        PreparedStatement ps = connection.prepareStatement("UPDATE USERS SET NAME=?, EMAIL=?, ADDRESS=?, DATEOFBIRTH=?, ISSTUDENT=?, BALANCE=? WHERE ID=?");
        ps.setInt(7, s.getID());
        ps.setString(1, s.getName());
        ps.setString(2, s.getEmail());
        ps.setString(3, s.getAddress());
        ps.setDate(4, Date.valueOf(s.getDateOfBirth()));
        ps.setBoolean(5, s.getStudent());
        ps.setDouble(6, s.getBalance());

        ps.executeUpdate();

    }

    public void deleteUser(User s) throws SQLException {
        PreparedStatement ps = connection.prepareStatement("DELETE FROM USERS WHERE ID=?");
        ps.setInt(1, s.getID());

        ps.executeUpdate();
    }


    public ArrayList<User> getUsers() throws SQLException {
        PreparedStatement ps = connection.prepareStatement("SELECT * FROM USERS");
        ResultSet rs = ps.executeQuery();
        ArrayList<User> Users = new ArrayList<>();
        while (rs.next()) {
            User temp = new User(
                    rs.getInt(1),
                    rs.getString(2),
                    rs.getString(3),
                    rs.getString(4),
                    rs.getDate(5).toLocalDate(),
                    rs.getBoolean(6),
                    rs.getDouble(7)
            );
            Users.add(temp);

        }
        return Users;

    }

    public ArrayList<User> getUsersByQuery(String s) throws SQLException {
        ArrayList<User> users = getUsers();
        ArrayList<User> temp = new ArrayList<>();
        for (User u : users) {
            if (u.getName().contains(s)) {
                temp.add(u);
            }
        }
        return temp;
    }

    public User getUser(int id) throws SQLException {
        ArrayList<User> users = getUsers();
        for (User u : users) {
            if (u.getID() == id) {
                return u;
            }
        }
        return null;
    }

}

