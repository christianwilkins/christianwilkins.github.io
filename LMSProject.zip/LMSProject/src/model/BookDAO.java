package model;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;

public class BookDAO {

    Connection connection;
    public int rows;

    public BookDAO(String s) throws SQLException {
        String url = s;
        connection = DriverManager.getConnection(url);
    }

    public void insertBook(Book s) throws SQLException {
        PreparedStatement ps = connection.prepareStatement("INSERT INTO BOOKS(name, author, publisher, genre, isbn, year) VALUES(?,?,?,?,?,?)");
        ps.setString(1, s.getName());
        ps.setString(2, s.getAuthor());
        ps.setString(3, s.getPublisher());
        ps.setString(4, s.getGenre());
        ps.setString(5, s.getISBN());
        ps.setLong(6, s.getYear());

        ps.executeUpdate();
    }

    public void updateBook(Book s) throws SQLException {
        PreparedStatement ps = connection.prepareStatement("UPDATE BOOKS SET NAME=?, AUTHOR=?, publisher=?, genre=?, isbn=?, year=? WHERE ID=?");
        ps.setInt(7, s.getID());
        ps.setString(1, s.getName());
        ps.setString(2, s.getAuthor());
        ps.setString(3, s.getPublisher());
        ps.setString(4, s.getGenre());
        ps.setString(5, s.getISBN());
        ps.setLong(6, s.getYear());

        ps.executeUpdate();

    }

    public void deleteBook(Book s) throws SQLException {
        PreparedStatement ps = connection.prepareStatement("DELETE FROM BookS WHERE ID=?");
        ps.setInt(1, s.getID());

        ps.executeUpdate();
    }


    public ArrayList<Book> getBooks() throws SQLException {
        PreparedStatement ps = connection.prepareStatement("SELECT * FROM BOOKS");
        ResultSet rs = ps.executeQuery();
        ArrayList<Book> books = new ArrayList<>();
        while (rs.next()) {
            Book temp = new Book(
                    rs.getInt(1),
                    rs.getString(2),
                    rs.getString(3),
                    rs.getString(4),
                    rs.getString(5),
                    rs.getString(6),
                    rs.getLong(7)
            );
            books.add(temp);

        }
        return books;

    }

    public ArrayList<Book> getBooksByQuery(String s) throws SQLException {
        ArrayList<Book> Books = getBooks();
        ArrayList<Book> temp = new ArrayList<>();
        for (Book u : Books) {
            if (u.getName().contains(s)) {
                temp.add(u);
            }
        }
        return temp;
    }

    public Book getBook(int id) throws SQLException {
        ArrayList<Book> Books = getBooks();
        for (Book u : Books) {
            if (u.getID() == id) {
                return u;
            }
        }
        return null;
    }

}

