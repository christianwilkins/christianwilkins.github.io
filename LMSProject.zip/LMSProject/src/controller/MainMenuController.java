package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.stage.Modality;
import javafx.stage.Stage;
import model.Library;

import java.io.IOException;
import java.sql.SQLException;

public class MainMenuController {

    Library library; // declares a variable called library

    public void passLibrary(Library library) {
        this.library = library;
    } // takes in the existing library into that variable, this method is also in every other controller

    @FXML
    void launchIssueBook(ActionEvent event) throws IOException, SQLException { // method that runs onAction for it's respective button, it creates a new window of what view is being chosen and shows it
        FXMLLoader loader = new FXMLLoader(getClass().getResource(("/view/issue-book.fxml"))); // new loader with the correct view
        Scene scene = new Scene(loader.load(), 1000, 600); // creates a new scene with the appropriate resolution
        Stage newWindow = new Stage(); // new window for launching scene
        Stage thisWindow = (Stage) ((Node) event.getSource()).getScene().getWindow(); // get this window so it can be the owner and we can modal
        IssueBookController controller = loader.getController(); // make a controller of the controller of the view we are about to show
        controller.passLibrary(library); // pass the library
        newWindow.setScene(scene); // set the scene
        newWindow.setTitle("Issue A Book"); // set the title
        newWindow.initOwner(thisWindow); // make the owner of the new window the main menu
        newWindow.initModality(Modality.WINDOW_MODAL); // make sure you can't do anything on the main menu until new window closes
        newWindow.showAndWait(); // show and wait
    } // every other method is very similar just using different views and class controllers

    @FXML
    void launchIssuedBooks(ActionEvent event) throws IOException, SQLException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource(("/view/issued-books.fxml")));
        Scene scene = new Scene(loader.load(), 600, 400);
        Stage newWindow = new Stage();
        Stage thisWindow = (Stage) ((Node) event.getSource()).getScene().getWindow();
        IssuedBooksController controller = loader.getController();
        controller.passLibrary(library);
        newWindow.setScene(scene);
        newWindow.setTitle("View Issued Books");
        newWindow.initOwner(thisWindow);
        newWindow.initModality(Modality.WINDOW_MODAL);
        newWindow.showAndWait();
    }

    @FXML
    void launchNewBook(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource(("/view/new-book.fxml")));
        Scene scene = new Scene(loader.load(), 500, 600);
        Stage newWindow = new Stage();
        Stage thisWindow = (Stage) ((Node) event.getSource()).getScene().getWindow();
        NewBookController controller = loader.getController();
        controller.passLibrary(library);
        newWindow.setScene(scene);
        newWindow.setTitle("Add A New Book");
        newWindow.initOwner(thisWindow);
        newWindow.initModality(Modality.WINDOW_MODAL);
        newWindow.showAndWait();
    }

    @FXML
    void launchNewUser(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource(("/view/new-user.fxml")));
        Scene scene = new Scene(loader.load(), 500, 600);
        Stage newWindow = new Stage();
        Stage thisWindow = (Stage) ((Node) event.getSource()).getScene().getWindow();
        NewUserController controller = loader.getController();
        controller.passLibrary(library);
        newWindow.setScene(scene);
        newWindow.setTitle("Add A New User");
        newWindow.initOwner(thisWindow);
        newWindow.initModality(Modality.WINDOW_MODAL);
        newWindow.showAndWait();
    }

    @FXML
    void launchReturnBook(ActionEvent event) throws IOException, SQLException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource(("/view/return-book.fxml")));
        Scene scene = new Scene(loader.load(), 600, 400);
        Stage newWindow = new Stage();
        Stage thisWindow = (Stage) ((Node) event.getSource()).getScene().getWindow();
        ReturnBookController controller = loader.getController();
        controller.passLibrary(library);
        newWindow.setScene(scene);
        newWindow.setTitle("Return A Book");
        newWindow.initOwner(thisWindow);
        newWindow.initModality(Modality.WINDOW_MODAL);
        newWindow.showAndWait();
    }

    @FXML
    void launchUserDetails(ActionEvent event) throws IOException, SQLException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource(("/view/user-details.fxml")));
        Scene scene = new Scene(loader.load(), 500, 600);
        Stage newWindow = new Stage();
        Stage thisWindow = (Stage) ((Node) event.getSource()).getScene().getWindow();
        UserDetailsController controller = loader.getController();
        controller.passLibrary(library);
        newWindow.setScene(scene);
        newWindow.setTitle("User Details");
        newWindow.initOwner(thisWindow);
        newWindow.initModality(Modality.WINDOW_MODAL);
        newWindow.showAndWait();
    }

}

