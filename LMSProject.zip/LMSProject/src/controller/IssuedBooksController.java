package controller;

import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import model.Library;
import model.Transaction;

import java.sql.SQLException;
import java.time.LocalDate;

public class IssuedBooksController {

    @FXML
    private TableColumn<Transaction, Integer> clmBookID;

    @FXML
    private TableColumn<Transaction, LocalDate> clmIssueDate;

    @FXML
    private TableColumn<Transaction, Integer> clmUserID;

    @FXML
    private TableView<Transaction> tblIssuedBooks;

    Library library;

    public void passLibrary(Library library) throws SQLException {
        this.library = library; // pass in the library and associate the columns with variables in the transactions
        clmBookID.setCellValueFactory(new PropertyValueFactory("bookID"));
        clmUserID.setCellValueFactory(new PropertyValueFactory("userID"));
        clmIssueDate.setCellValueFactory(new PropertyValueFactory("issueDate"));
        for (Transaction transaction : library.transactions.getTransactions()) {
            if (transaction.isStatus()) { // for each active transaction add it to the table
                tblIssuedBooks.getItems().add(transaction);
            }
        }
    }

}
