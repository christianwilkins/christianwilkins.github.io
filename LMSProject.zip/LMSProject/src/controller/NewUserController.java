package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.stage.Stage;
import model.Library;
import model.User;

import java.sql.SQLException;

public class NewUserController {

    @FXML
    private DatePicker dtpDOB;

    @FXML
    private RadioButton rdbFaculty;

    @FXML
    private RadioButton rdbStudent;

    @FXML
    private TextArea txaAddress;

    @FXML
    private TextField txtEmail;

    @FXML
    private TextField txtName;

    @FXML
    private ToggleGroup userType;

    Library library;

    public void passLibrary(Library library) {
        this.library = library;
    } // take in the library

    @FXML
    void registerUser(ActionEvent event) throws SQLException { // registers a user when the button is clicked
        // creates and adds a user to the library
        User user = new User(txtName.getText(), txtEmail.getText(), txaAddress.getText(), dtpDOB.getValue(), rdbStudent.isSelected());
        library.addUser(user);
        // creating and showing an alert to confirm the registration
        Alert a = new Alert(Alert.AlertType.INFORMATION);
        a.setTitle("Registration Successful");
        a.setHeaderText("Registered " + user.getName());
        Stage thisStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        a.initOwner(thisStage);
        Stage primaryStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        primaryStage.hide();
        a.showAndWait();
    }

}
