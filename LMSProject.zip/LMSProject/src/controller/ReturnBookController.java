package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import model.Book;
import model.Library;
import model.User;

import java.sql.SQLException;
import java.util.Locale;

public class ReturnBookController {

    @FXML
    private Label lblMessage;

    @FXML
    private ListView<Book> lstBookResults;

    @FXML
    private TextField txtBookID;

    @FXML
    private TextField txtBookSearch;

    Library library;

    public void passLibrary(Library library) throws SQLException {
        this.library = library;
        for (Book book : library.books.getBooks()) {
            lstBookResults.getItems().add(book);
        }
        lblMessage.setText("");
    }

    @FXML
    void searchBook(KeyEvent event) throws SQLException { // same search as in the issue book controller
        lstBookResults.getItems().clear();
        String search = txtBookSearch.getText().toLowerCase(Locale.ROOT);
        for (Book book : library.books.getBooks()) {
            if (book.getName().toLowerCase(Locale.ROOT).contains(search)) {
                lstBookResults.getItems().add(book);
            }
        }
    }

    @FXML
    void updateBookID(MouseEvent event) { // same update to text field as in the issue book controller
        Book book = lstBookResults.getSelectionModel().getSelectedItem();
        if (book != null)
            txtBookID.setText("" + book.getID());
    }

    @FXML
    void returnBook(ActionEvent event) throws SQLException { // returns the book on button clicked
        if (!txtBookID.getText().isBlank()) {
            if (library.returnBook(Integer.parseInt(txtBookID.getText()))) { // if the book can be returned
                lblMessage.setText(library.msgLog.get(library.msgLog.size() - 1)); // show the message
                Color paint = new Color(0.0, 0.502, 0.0, 1.0);
                lblMessage.setTextFill(paint);
            } else { // if the book cannot be returned show the reasoning
                lblMessage.setText(library.msgLog.get(library.msgLog.size() - 1));
                Color paint = new Color(1.0, 0.0, 0.0, 1.0);
                lblMessage.setTextFill(paint);
            }
        } else { // if the txt field is empty show this message in red
            lblMessage.setText("The input is empty.");
            Color paint = new Color(1.0, 0.0, 0.0, 1.0);
            lblMessage.setTextFill(paint);
        }
    }

}
