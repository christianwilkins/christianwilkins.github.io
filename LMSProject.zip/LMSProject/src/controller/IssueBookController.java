package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import model.Book;
import model.Library;
import model.User;

import java.sql.SQLException;
import java.util.Locale;

public class IssueBookController {

    @FXML
    private ListView<Book> lstBookResults;

    @FXML
    private Label lblMessage;

    @FXML
    private ListView<User> lstUserResults;

    @FXML
    private TextField txtBookID;

    @FXML
    private TextField txtBookSearch;

    @FXML
    private TextField txtUserID;

    @FXML
    private TextField txtUserSearch;

    @FXML
    void searchBook(KeyEvent event) throws SQLException { // every time a key is typed in the book search text field this method is called
        lstBookResults.getItems().clear(); // clears the search results
        String search = txtBookSearch.getText().toLowerCase(Locale.ROOT).trim(); // gets the input and makes it lowercase and trims spaces
        for (Book book : library.books.getBooks()) { // goes through the books in the library
            if (book.getName().toLowerCase(Locale.ROOT).contains(search)) { // if the name of the book contains the search it is added
                lstBookResults.getItems().add(book); // to the list view of results
            }
        }
    }
    // search user is the same thing but with the user controls instead
    @FXML
    void searchUser(KeyEvent event) throws SQLException {
        lstUserResults.getItems().clear();
        String search = txtUserSearch.getText().toLowerCase(Locale.ROOT);
        for (User user : library.users.getUsers()) {
            if (user.getName().toLowerCase(Locale.ROOT).contains(search)) {
                lstUserResults.getItems().add(user);
            }
        }
    }

    @FXML
    void updateBookID(MouseEvent event) { // when the book results list view is clicked this method is called
        Book book = lstBookResults.getSelectionModel().getSelectedItem(); // gets the selected book
        txtBookID.setText("" + book.getID()); // puts that book's ID in the text field
    }
    // same thing again just with user instead
    @FXML
    void updateUserID(MouseEvent event) {
        User user = lstUserResults.getSelectionModel().getSelectedItem();
        txtUserID.setText("" + user.getID());
    }

    @FXML
    void issueBook(ActionEvent event) throws SQLException { // checks to see if the selected book can be issued to the selected user and does it if possible
        if (!txtUserID.getText().isBlank() && !txtBookID.getText().isBlank()) {
            Book book = library.getBook(Integer.parseInt(txtBookID.getText())); // gets the book and user from the library
            User user = library.getUser(Integer.parseInt(txtUserID.getText()));
            if (library.issueBook(user.getID(), book.getID())) { // sees if issuing the book is possible
                lblMessage.setText(library.msgLog.get(library.msgLog.size() - 2) +"\n" + library.msgLog.get(library.msgLog.size() - 1)); // in this case we have to get the 2 most recent msgs
                Color paint = new Color(0.0, 0.502, 0.0, 1.0);
                lblMessage.setTextFill(paint); // sets the label to the message in the library's log and makes it the right color
            } else { // if the book can't be issued the msgLog will have why so we put the most recent msg in the label
                lblMessage.setText(library.msgLog.get(library.msgLog.size() - 1));
                Color paint = new Color(1.0, 0.0, 0.0, 1.0);
                lblMessage.setTextFill(paint); // sets the label to the message in the library's log and makes it the right color
            }
        } else { // if one or both of the fields are blank will print a message about it... this could also be done with every other text field if needed
            lblMessage.setText("One or both of the inputs are empty.");
            Color paint = new Color(1.0, 0.0, 0.0, 1.0);
            lblMessage.setTextFill(paint);
        }
    }

    Library library;

    public void passLibrary(Library library) throws SQLException {
        this.library = library;
        for (User user : library.users.getUsers()) { // fills up the lists at the beginning of the window opening when the library is obtained
            lstUserResults.getItems().add(user);
        }
        for (Book book : library.books.getBooks()) {
            lstBookResults.getItems().add(book);
        }
        lblMessage.setText(""); // makes the message label empty so you can't see it until needed
    }

}
