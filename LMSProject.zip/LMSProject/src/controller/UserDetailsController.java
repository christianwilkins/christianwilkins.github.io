package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import model.Book;
import model.Library;
import model.Transaction;
import model.User;

import java.sql.SQLException;

public class UserDetailsController {

    @FXML
    private Button btnFines;

    @FXML
    private ComboBox<User> cmbUser;

    @FXML
    private Label lblAddress;

    @FXML
    private Label lblBalance;

    @FXML
    private Label lblBirthday;

    @FXML
    private Label lblEmail;

    @FXML
    private Label lblName;

    @FXML
    private Label lblUserType;

    @FXML
    private ListView<Book> lstCheckedOutBooks;

    @FXML
    void loadUser(ActionEvent event) throws SQLException { // combobox onAction that calls this method when an action on the combobox is performed
        if (cmbUser.getSelectionModel().getSelectedItem() != null) { // if the combobox has a not null selection
            User user = cmbUser.getSelectionModel().getSelectedItem(); // then get the user
            checkUser(user); // and call this method to check their details
        }
    }

    @FXML
    void collectFines(ActionEvent event) {
        User user = cmbUser.getSelectionModel().getSelectedItem();
        user.setBalance(0);
        lblBalance.setText("$" + user.getBalance());
        btnFines.setVisible(false);
    }

    public void checkUser(User user) throws SQLException { // method that gets the user and puts their details on the labels
        lblName.setText(user.getName()); // sets name to user's name, email ... etc.
        lblEmail.setText(user.getEmail());
        lblAddress.setText(user.getAddress());
        lblBirthday.setText(user.getDateOfBirth().toString());
        if (user.getStudent()) { // sets to student or faculty based on boolean in user
            lblUserType.setText("Student");
        } else {
            lblUserType.setText("Faculty");
        }
        lblBalance.setText("$" + user.getBalance()); // sets balance and makes sure to add dollar sign in front
        if (user.getBalance() > 0) { // if the user has an outstanding balance show the collect fines button else make it not visible
            btnFines.setVisible(true);
        } else {
            btnFines.setVisible(false);
        }
        lstCheckedOutBooks.getItems().clear(); // clear the checked out books list
        for (Transaction transaction : library.transactions.getTransactions()) { // add a book to the list using the book ID from the transaction if the user ID matches the user in the transaction and the transaction status is true
            if (transaction.getUserID() == user.getID() && transaction.isStatus()) {
                lstCheckedOutBooks.getItems().add(library.getBook(transaction.getBookID()));
            }
        }
    }

    Library library;

    public void passLibrary(Library library) throws SQLException {
        this.library = library;
        for (User user : library.users.getUsers()) { // adding all library users to the combo box
            cmbUser.getItems().add(user);
        }
        btnFines.setVisible(false); // making the button not visible and the labels empty
        lblBalance.setText("");
        lblUserType.setText("");
        lblBirthday.setText("");
        lblAddress.setText("");
        lblEmail.setText("");
        lblName.setText("");
    }

}

