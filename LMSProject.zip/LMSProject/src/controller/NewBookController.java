package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.Book;
import model.Library;

import java.sql.SQLException;

public class NewBookController {

    @FXML
    private ComboBox<String> cmbGenre;

    @FXML
    private ListView<String> lstPublisher;

    @FXML
    private TextField txtAuthor;

    @FXML
    private TextField txtISBN;

    @FXML
    private TextField txtName;

    @FXML
    private TextField txtYear;

    Library library;

    public void passLibrary(Library library) {
        this.library = library;
    }

    @FXML
    void registerBook(ActionEvent event) throws SQLException {
        // creates a book and adds it to the library
        Book book = new Book(txtName.getText(), txtAuthor.getText(), lstPublisher.getSelectionModel().getSelectedItem(), cmbGenre.getValue(), txtISBN.getText(), Long.parseLong(txtYear.getText()));
        library.addBook(book);
        // creates and shows an alert that confirms the addition
        Alert a = new Alert(Alert.AlertType.INFORMATION);
        a.setTitle("Registration Successful");
        a.setHeaderText("Registered " + book.getName());
        Stage thisStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        a.initOwner(thisStage);
        Stage primaryStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        primaryStage.hide();
        a.showAndWait();
    }

    public void initialize() {
        // adding in the publisher and genre options when the view is loaded
        lstPublisher.getItems().addAll("Pearson", "Penguin", "RELX", "Thomson Reuters", "HarperCollins", "Macmillan");
        cmbGenre.getItems().addAll("Education", "Adventure", "Horror", "History", "Fantasy", "Classic", "Graphic Novel", "Mystery");
    }

}
