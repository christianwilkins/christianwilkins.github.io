package com.atomicobject.othello;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.ListIterator;

public class AI {

    int Player;
    int Opponent;
    int OpponentCount;
    int PlayerCount;
    int Row = 7;
    int Col = 7;
    ListIterator<int[]> moveList;
    GameState ourState;
    int[][] valueArr = {
            {25, 5, 15, 15, 15, 15, 5, 25},
            {5, 5, 6, 6, 6, 6, 5, 5},
            {15, 6, 10, 10, 10, 10, 6, 15},
            {15, 6, 10, 8, 8, 10, 6, 15},
            {15, 6, 10, 8, 8, 10, 6, 15},
            {15, 6, 10, 10, 10, 10, 6, 15},
            {5, 5, 6, 6, 6, 6, 5, 5},
            {25, 5, 15, 15, 15, 15, 5, 25}
    };
    int[][] flips = new int[Row + 1][Col + 1];
    int[][] goesThroughCenter = new int[Row + 1][Col + 1];
    int lateGame = 44;

    public AI(int[][] moves) {
        moveList = Arrays.asList(moves).listIterator();
    }

    public int[] computeMove(GameState state) {
        System.out.println("AI returning canned move for game state - " + state);
        System.out.println("Beginning board:");
        int[][] array2 = state.getBoard();
        for (int i = 0; i <= Row; i++) {
            for (int j = 0; j <= Col; j++) {
                System.out.print(array2[i][j] + ", ");
                flips[i][j] = 0;
                goesThroughCenter[i][j] = 0;
            }
            System.out.println();
        }
        int[] move = {0, 0};
        ourState = state;
        Player = state.getPlayer();
        System.out.println(Player);
        if (Player == 1) {
            Opponent = 2;
        } else {
            Opponent = 1;
        }

        findMoves();

        System.out.println("Final Board:");
        int[][] array = ourState.getBoard();
        for (int i = 0; i <= Row; i++) {
            for (int j = 0; j <= Col; j++) {
                System.out.print(array[i][j] + ", ");
            }
            System.out.println();
        }
        System.out.println();

        for (int i = 0; i < 50000; i++) {
            continue;
        }

        return SelectMove(valueBoardCrossmap());
    }

    public int getPlayerCount(GameState state) {
        int[][] board = state.getBoard();
        int count = 0;
        int i, j = 0;
        for (i = 0; i <= Row; i++) {//row
            for (j = 0; j <= Col; j++) {//column
                if (board[i][j] == Player) {
                    count++;
                }
            }
        }
        return count;
    }

    public int getOpponentCount(GameState state) {
        int[][] board = state.getBoard();
        int count = 0;
        int i, j = 0;
        for (i = 0; i <= Row; i++) {//row
            for (j = 0; j <= Col; j++) {//column
                if (board[i][j] == Opponent) {
                    count++;
                }
            }
        }
        return count;
    }

    public void findMoves() {
        int[][] board = ourState.getBoard();
        for (int i = 0; i < board.length; i++) {
            for (int j = 0; j < board.length; j++) {
                if (board[i][j] == Player) {
                    findDir(i, j, ourState.getBoard());
                }
            }
        }
    }

    public void findDir(int row, int col, int[][] board) {
        for (int i = row - 1; i <= row + 1; i++) {
            for (int j = col - 1; j <= col + 1; j++) {
                if (isInBounds(i, j)) {
                    if (board[i][j] == Opponent) {
                        int dR = i - row;
                        int dC = j - col; // Passing i, j, dR, dC
                        CheckDirection(i, j, dR, dC);
                    }
                }
            }
        }
    }

    public void CheckDirection(int row, int col, int difference_Row, int difference_Col) {
        int flipCount = 0;
        int middleCount = 0;
        int[][] board = ourState.getBoard();
        while (isInBounds(row, col)) {
            if (board[row][col] == 0) {
                board[row][col] = 3;
                ourState.setBoard(board);
                flips[row][col] = flipCount;
                goesThroughCenter[row][col] = middleCount;
                return;
            } else if (board[row][col] == Player) {
                return;
            } else if (board[row][col] == 3) {
                return;
            } else {
                flipCount++;
                if ((row >= 3) && (row <= 4) && (col >= 3) && (col <= 4)) {
                    middleCount++;
                }
                row = row + difference_Row;
                col = col + difference_Col;
            }
        }
        return;
    }

    public int[][] valueBoardCrossmap() {
        int[][] board = ourState.getBoard();
        int[][] value = new int[Row + 1][Col + 1];
        for (int i = 0; i <= Row; i++) {
            for (int j = 0; j <= Col; j++) {
                if (board[i][j] == 3 && isInBounds(i, j)) {
                    if (getOpponentCount(ourState) + getPlayerCount(ourState) > lateGame && valueArr[i][j] == 5) {
                        valueArr[i][j] = 10;
                        value[i][j] = valueArr[i][j] + flips[i][j] + goesThroughCenter[i][j];
                    } else if (getOpponentCount(ourState) + getPlayerCount(ourState) > lateGame) {
                        value[i][j] = valueArr[i][j] + flips[i][j] + goesThroughCenter[i][j];
                    } else {
                        value[i][j] = valueArr[i][j] - flips[i][j] + goesThroughCenter[i][j];
                    }
                } else {
                    value[i][j] = 0;
                }
            }
        }
        return value;
    }

    public int[] SelectMove(int[][] PlayableValueBoard) {
        int[] move = new int[2];
        for (int max = 31; max >= -1; max--) {
            for (int i = 0; i <= Row; i++) {
                for (int j = 0; j <= Col; j++) {
                    if (PlayableValueBoard[i][j] == max) {
                        move[0] = i;
                        move[1] = j;
                        return move;
                    }
                }
            }
        }
        return move;
    }

    public boolean isInBounds(int i, int j) {
        if ((i >= 0 && i <= 7) && (j >= 0 && j <= 7)) {
            return true;
        }
        return false;
    }
}
