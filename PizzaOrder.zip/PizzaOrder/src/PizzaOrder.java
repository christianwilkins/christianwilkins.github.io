/*
POOP Inc. Pizza App
The app lets users create and customize a pizza order using JavaFX to display a visual representation of their order
Users can also save their creation to a save location of their choice

@author  Christian Wilkins
@version 1.0
@since   2022-02-20
 */

import javafx.application.Application;
import javafx.embed.swing.SwingFXUtils;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.image.WritableImage;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import javax.imageio.ImageIO;
import java.awt.image.RenderedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Locale;

public class PizzaOrder extends Application {

    /*
    App Design Structure in terms of what is inside what in the scene

    root (hbox)
        lblTitle
        order (gridpane but I use it like a hbox)
            options (vbox)
                I add everything that is needed on the order formand things that can be added vertically are added
                directly like lblSize/lblCrust for example but some things must be added to a hbox then added to
                options to give them a vertical look like lblSauce and its corresponding toggle buttons
                see configOptions() method for more details
            pizzaPane (stackpane)
                pizzaPane holds all the images according to what should be shown based on what the value of the
                attributes of the pizza object are, order is also important here as we want the crust to be the lowest
                and so on so nothing looks wrong
                see fillStackPane() method for more details
     */

    // declare variables for the scene
    Scene scene;
    VBox root;
    GridPane order;
    VBox options;
    StackPane pizzaPane;
    Label lblTitle;

    // controls for size options
    Label lblSize;
    HBox sizeBox;
    ToggleGroup sizeGroup;
    RadioButton rdbSmall;
    RadioButton rdbMedium;
    RadioButton rdbLarge;

    // controls for crust options
    Label lblCrust;
    HBox crustBox;
    ToggleGroup crustGroup;
    RadioButton rdbChicago;
    RadioButton rdbNYC;

    // controls for sauce options
    HBox sauceBox;
    Label lblSauce;
    ToggleGroup sauceGroup;
    ToggleButton tgbMarinara;
    ToggleButton tgbBarbeque;
    ToggleButton tgbAlfredo;
    ToggleButton tgbChipotle;

    // controls for cheese options
    HBox cheeseBox;
    Label lblCheese;
    ComboBox<String> cmbCheese;

    // controls for topping options
    Label lblToppings;
    GridPane grdToppings;
    /*
    CheckBox chkMushroom;
    CheckBox chkOnion;
    CheckBox chkOlive;
    CheckBox chkPepper;
    CheckBox chkTomato;
    CheckBox chkJalapeno;
    CheckBox chkHam;
    CheckBox chkChicken;
    CheckBox chkPepperoni;
     */
    ArrayList<CheckBox> chkToppings = new ArrayList<>();

    // controls for seasoning option
    CheckBox chkSeasoning;

    // controls for submit and reset options
    HBox submitBox;
    Button btnSubmit;
    Button btnReset;
    Label lblDelivery;

    // creating a pizza object
    Pizza pizza = new Pizza();

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage stage) throws Exception {
        //System.out.println(pizza.getSaucePath());

        // instantiate main variables
        root = new VBox();
        lblTitle = new Label("Build Your Own Pizza!");
        order = new GridPane();
        options = new VBox();
        pizzaPane = new StackPane();

        // method to instantiate controls and place them onto the options vbox in proper order
        configOptions();
        // method to fill the stack pane based on the pizza's values
        fillStackPane();
        // method to have controls selected based on the pizza default constructor
        initializeButtons();

        lblTitle.getStyleClass().add("title");
        lblTitle.setPadding(new Insets(20));

        //order.getChildren().addAll(options, pizzaPane);
        // had order as a hbox before I changed it to a gridpane because I wanted to try to center the pizza when size
        // is changed
        // trying to get the pizza in the middle more or less of the screen can't find a way to keep it static in a
        // location as it is resized
        pizzaPane.setPadding(new Insets(75));
        // options and pizzapane both get half of the screen
        options.setMaxHeight(800);
        options.setMaxWidth(600);
        options.setFillWidth(true);
        pizzaPane.setMaxHeight(800);
        pizzaPane.setMaxWidth(600);
        // trying to get the pizza to be in the center of it's half of the screen
        pizzaPane.setAlignment(Pos.CENTER);
        pizzaPane.setPadding(new Insets(90,90,90,90));
        // options on left and pizza on right
        order.add(options, 0, 0);
        order.add(pizzaPane, 1, 0);

        // adding the two pieces to root
        root.getChildren().addAll(lblTitle, order);
        root.setAlignment(Pos.TOP_CENTER);
        root.setId("root");

        // 1200 by 800 resolution
        scene = new Scene(root, 1200, 800);
        // includes the css file and sets title
        scene.getStylesheets().add("assets/stylesheets/styles.css");
        stage.setScene(scene);
        stage.setTitle("Procedural Object-Oriented Pizza Company (P00P) Pizza Shop");
        stage.show();

        // on action for changing the selected size group radio button
        sizeGroup.selectedToggleProperty().addListener(e -> {
            ToggleButton temp = (ToggleButton) sizeGroup.getSelectedToggle();
            String str = temp.getText(); // gets the selected button and takes text from it
            pizza.setSize(str.toLowerCase(Locale.ROOT)); // sets the size
            fillStackPane(); // update the image
        });

        crustGroup.selectedToggleProperty().addListener(e -> {
            ToggleButton temp = (ToggleButton) crustGroup.getSelectedToggle();
            String str = temp.getText(); // same thing as size
            switch (str) { // but this time we need to send something different from what is in the button's text
                case "Chicago Style Deep Dish" -> pizza.setCrust("chicago");
                case "New York Thin Crust" -> pizza.setCrust("nyc");
                default -> {
                }
            } // it could have been like the others, but I wanted all the attributes to be simple and preferably one word long
            fillStackPane();
        });

        // same thing as size
        sauceGroup.selectedToggleProperty().addListener(e -> {
            ToggleButton temp = (ToggleButton) sauceGroup.getSelectedToggle();
            String str = "none";
            if (temp != null) { // only call .getText if temp is not null, if null there will be an error
                str = temp.getText();
            }
            pizza.setSauce(str.toLowerCase(Locale.ROOT));
            fillStackPane();
        });

        // same thing as size but getting the string from the combo-box instead
        cmbCheese.setOnAction(e -> {
            String selected = cmbCheese.getValue();
            pizza.setCheese(selected.toLowerCase(Locale.ROOT));
            fillStackPane();
        });

        // for each topping checkbox we need call the checkToppings method for the respective checkbox
        /* old solution
        chkMushroom.selectedProperty().addListener(e -> checkToppings(chkMushroom));

        chkJalapeno.selectedProperty().addListener(e -> checkToppings(chkJalapeno));

        chkOnion.selectedProperty().addListener(e -> checkToppings(chkOnion));

        chkHam.selectedProperty().addListener(e -> checkToppings(chkHam));

        chkOlive.selectedProperty().addListener(e -> checkToppings(chkOlive));

        chkChicken.selectedProperty().addListener(e -> checkToppings(chkChicken));

        chkPepper.selectedProperty().addListener(e -> checkToppings(chkPepper));

        chkPepperoni.selectedProperty().addListener(e -> checkToppings(chkPepperoni));

        chkTomato.selectedProperty().addListener(e -> checkToppings(chkTomato));
        */

        // new solution
        for (CheckBox checkBox: chkToppings) {
            checkBox.selectedProperty().addListener(e -> checkToppings(checkBox));
        }


        // set the seasoning value in pizza to the selected value of the seasoning checkbox
        chkSeasoning.selectedProperty().addListener(e -> {
            boolean isChecked = chkSeasoning.isSelected();
            pizza.setSeasoning(isChecked);
            fillStackPane();
        });

        // calls the pizza's reset method when clicked and makes sure the buttons selected are correct as well
        btnReset.setOnAction(e -> {
            pizza.reset();
            initializeButtons();
            fillStackPane();
        });

        // when clicked sets the label's text to where the pizza is delivered based on what user selected in the given
        // image saving file method that passes the stack pane
        btnSubmit.setOnAction(e -> lblDelivery.setText("Pizza delivered to " + captureAndSaveDisplay(pizzaPane)));
    }

    public void initializeButtons() {
        // gets the value of each attribute and selects the controls accordingly
        switch (pizza.getSize()) {
            case "small" -> rdbSmall.setSelected(true);
            case "medium" -> rdbMedium.setSelected(true);
            case "large" -> rdbLarge.setSelected(true);
        }

        switch (pizza.getCrust()) {
            case "chicago" -> rdbChicago.setSelected(true);
            case "nyc" -> rdbNYC.setSelected(true);
        }

        switch (pizza.getSauce()) {
            case "marinara":
                tgbMarinara.setSelected(true);
                break;
            case "barbeque":
                tgbBarbeque.setSelected(true);
                break;
            case "alfredo":
                tgbAlfredo.setSelected(true);
                break;
            case "chipotle":
                tgbChipotle.setSelected(true);
                break;
            case "none":
                break;
        }

        switch (pizza.getCheese()) {
            case "none" -> cmbCheese.setValue("None");
            case "normal" -> cmbCheese.setValue("Normal");
            case "extra" -> cmbCheese.setValue("Extra");
        }

        if (pizza.isSeasoned()) {
            chkSeasoning.setSelected(true);
        }

        // sets everything but the defaults to false, if you set the defaults here false sometimes this doesn't work
        // ^fixed when using arraylist
        /* old solution
        chkTomato.setSelected(false);
        chkChicken.setSelected(false);
        chkHam.setSelected(false);
        chkJalapeno.setSelected(false);
        chkOlive.setSelected(false);
        chkOnion.setSelected(false);
         */

        // new solution
        for (CheckBox c : chkToppings) {
            if (pizza.getToppings().contains(c.getText().toLowerCase(Locale.ROOT))) {
                c.setSelected(true);
            } else {
                c.setSelected(false);
            }
        }
        /* old solution
        // temp points to toppings arraylist in pizza
        ArrayList<String> temp = pizza.getToppings();
        // for each topping in the arraylist set the checkbox selected to true
        for (String s : temp) {
            switch (s) {
                case "chicken" -> chkChicken.setSelected(true);
                case "ham" -> chkHam.setSelected(true);
                case "jalapeno" -> chkJalapeno.setSelected(true);
                case "mushroom" -> chkMushroom.setSelected(true);
                case "olive" -> chkOlive.setSelected(true);
                case "onion" -> chkOnion.setSelected(true);
                case "pepper" -> chkPepper.setSelected(true);
                case "pepperoni" -> chkPepperoni.setSelected(true);
                case "tomato" -> chkTomato.setSelected(true);
            }
        }

         */
    }

    public void checkToppings(CheckBox checkBox) {
        boolean isChecked = checkBox.isSelected(); // store whether the checkbox is clicked in a boolean
        if (isChecked) { // if it is checked add the topping to the arraylist in pizza
            pizza.addTopping(checkBox.getText().toLowerCase(Locale.ROOT));
        } else { // if it is not checked remove the topping from the arraylist in pizza
            pizza.removeTopping(checkBox.getText().toLowerCase(Locale.ROOT));
        }
        fillStackPane(); // update image
    }

    public void configOptions() {
        // add everything to the options vbox in order
        // change spacing and alignment as necessary
        // make sure radio and toggle buttons are in the correct groups
        // if a category needs to be displayed horizontally a hbox will be created then the horizontal elements will be
        // added and then added to options (ex. size radio buttons)
        options.setAlignment(Pos.CENTER);
        options.setSpacing(10);
        options.setPadding(new Insets(10));

        Separator sizeSeperator = new Separator();
        lblSize = new Label("Choose your size");
        rdbSmall = new RadioButton("Small");
        rdbMedium = new RadioButton("Medium");
        rdbLarge = new RadioButton("Large");
        sizeGroup = new ToggleGroup();
        rdbSmall.setToggleGroup(sizeGroup);
        rdbMedium.setToggleGroup(sizeGroup);
        rdbLarge.setToggleGroup(sizeGroup);
        sizeBox = new HBox();
        sizeBox.setAlignment(Pos.CENTER);
        sizeBox.setSpacing(15);
        sizeBox.getChildren().addAll(rdbSmall, rdbMedium, rdbLarge);
        options.getChildren().addAll(lblSize, sizeBox, sizeSeperator);

        Separator crustSeperator = new Separator();
        lblCrust = new Label("Choose your crust");
        rdbChicago = new RadioButton("Chicago Style Deep Dish");
        rdbNYC = new RadioButton("New York Thin Crust");
        crustGroup = new ToggleGroup();
        rdbChicago.setToggleGroup(crustGroup);
        rdbNYC.setToggleGroup(crustGroup);
        crustBox = new HBox();
        crustBox.setAlignment(Pos.CENTER);
        crustBox.setSpacing(15);
        crustBox.getChildren().addAll(rdbChicago, rdbNYC);
        options.getChildren().addAll(lblCrust, crustBox, crustSeperator);

        Separator sauceSeperator = new Separator();
        lblSauce = new Label("Choose your sauce");
        tgbMarinara = new ToggleButton("Marinara");
        tgbMarinara.getStyleClass().add("marinara");
        tgbBarbeque = new ToggleButton("Barbeque");
        tgbBarbeque.getStyleClass().add("barbeque");
        tgbAlfredo = new ToggleButton("Alfredo");
        tgbAlfredo.getStyleClass().add("alfredo");
        tgbChipotle = new ToggleButton("Chipotle");
        tgbChipotle.getStyleClass().add("chipotle");
        sauceGroup = new ToggleGroup();
        tgbMarinara.setToggleGroup(sauceGroup);
        tgbBarbeque.setToggleGroup(sauceGroup);
        tgbAlfredo.setToggleGroup(sauceGroup);
        tgbChipotle.setToggleGroup(sauceGroup);
        sauceBox = new HBox();
        sauceBox.setAlignment(Pos.CENTER);
        sauceBox.setSpacing(15);
        sauceBox.getChildren().addAll(lblSauce, tgbMarinara, tgbBarbeque, tgbAlfredo, tgbChipotle);
        options.getChildren().addAll(sauceBox, sauceSeperator);

        Separator cheeseSeperator = new Separator();
        lblCheese = new Label("Choose cheese level");
        cmbCheese = new ComboBox<>();
        cmbCheese.getStyleClass().add("cheese");
        cmbCheese.getItems().addAll("None", "Normal", "Extra");
        cheeseBox = new HBox();
        cheeseBox.setAlignment(Pos.CENTER);
        cheeseBox.setSpacing(15);
        cheeseBox.getChildren().addAll(lblCheese, cmbCheese);
        options.getChildren().addAll(cheeseBox, cheeseSeperator);

        // add each checkbox to the grid pane accordingly
        Separator toppingsSeperator = new Separator();
        lblToppings = new Label("Choose your toppings");
        grdToppings = new GridPane();
        grdToppings.setAlignment(Pos.CENTER);
        grdToppings.setPadding(new Insets(15));

        /*
        chkMushroom = new CheckBox("Mushroom");
        grdToppings.add(chkMushroom, 0, 0);
        chkJalapeno = new CheckBox("Jalapeno");
        grdToppings.add(chkJalapeno, 1, 0);
        chkOnion = new CheckBox("Onion");
        grdToppings.add(chkOnion, 0, 1);
        chkHam = new CheckBox("Ham");
        grdToppings.add(chkHam, 1, 1);
        chkOlive = new CheckBox("Olive");
        grdToppings.add(chkOlive, 0, 2);
        chkChicken = new CheckBox("Chicken");
        grdToppings.add(chkChicken, 1, 2);
        chkPepper = new CheckBox("Pepper");
        grdToppings.add(chkPepper, 0, 3);
        chkPepperoni = new CheckBox("Pepperoni");
        grdToppings.add(chkPepperoni, 1, 3);
        chkTomato = new CheckBox("Tomato");
        grdToppings.add(chkTomato, 0, 4);
         */

        chkToppings.add(new CheckBox("Mushroom"));
        chkToppings.add(new CheckBox("Jalapeno"));
        chkToppings.add(new CheckBox("Onion"));
        chkToppings.add(new CheckBox("Ham"));
        chkToppings.add(new CheckBox("Olive"));
        chkToppings.add(new CheckBox("Chicken"));
        chkToppings.add(new CheckBox("Pepper"));
        chkToppings.add(new CheckBox("Pepperoni"));
        chkToppings.add(new CheckBox("Tomato"));
        int ct = 0;
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 2; j++) {
                if(ct == chkToppings.size()) {break;}
                grdToppings.add(chkToppings.get(ct), j, i);
                ct++;
            }
        }
        
        options.getChildren().addAll(lblToppings, grdToppings, toppingsSeperator);

        Separator seasoningSeperator = new Separator();
        chkSeasoning = new CheckBox("Add Seasoning?");
        options.getChildren().addAll(chkSeasoning, seasoningSeperator);

        lblDelivery = new Label();
        btnSubmit = new Button("Submit Order");
        btnSubmit.getStyleClass().add("submit");
        btnReset = new Button("Reset Order");
        btnReset.getStyleClass().add("reset");
        submitBox = new HBox();
        submitBox.setSpacing(15);
        submitBox.setAlignment(Pos.CENTER);
        submitBox.getChildren().addAll(btnSubmit, btnReset);
        options.getChildren().addAll(submitBox, lblDelivery);
    }

    public void fillStackPane() {
        // check the size first and set the value to how many pixels the height and width will be
        int size = switch (pizza.getSize()) {
            case "small" -> 350;
            case "medium" -> 400;
            case "large" -> 450;
            default -> 0;
        };

        // clear the stack pane
        pizzaPane.getChildren().clear();
        // create an arraylist of ImageViews that receives an arraylist of IVs from the pizza's getImages method
        ArrayList<ImageView> imageViews;
        imageViews = pizza.getImages();
        // for every imageview received
        for (ImageView i : imageViews) {
            i.setFitHeight(size); // set the height and width to the selected size
            i.setFitWidth(size);
            pizzaPane.getChildren().add(i); // add the imageview to the pizza-pane
        }
        pizzaPane.setAlignment(Pos.CENTER); // center it
    }

    //given method implementation
    public String captureAndSaveDisplay(StackPane pizzaLayers) {

        // Adapted from: https://stackoverflow.com/questions/38028825/javafx-save-view-of-pane-to-image/38028893

        FileChooser fileChooser = new FileChooser();
        //Set extension filter
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("png files (*.png)", "*.png"));
        //Prompt user to select a file
        File file = fileChooser.showSaveDialog(null);

        if (file != null) {
            try {
                //Set the capture area
                WritableImage writableImage = new WritableImage((int) pizzaLayers.getWidth(), (int) pizzaLayers.getHeight());
                pizzaLayers.snapshot(null, writableImage);
                RenderedImage renderedImage = SwingFXUtils.fromFXImage(writableImage, null);
                //Write the snapshot to the chosen file
                ImageIO.write(renderedImage, "png", file);
                return file.getAbsolutePath();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
        return null;
    }
}


class Pizza {
    private String size;
    private String crust;
    private String sauce;
    private String cheese;
    private ArrayList<String> toppings;
    private boolean seasoning;

    public Pizza() {
        size = "medium";
        crust = "chicago";
        sauce = "marinara";
        cheese = "normal";
        toppings = new ArrayList<>();
        toppings.add("mushroom");
        toppings.add("pepper");
        toppings.add("pepperoni");
        seasoning = true;
    }

    public void reset() { // same thing as the constructor but clears toppings instead of instantiating it
        size = "medium";
        crust = "chicago";
        sauce = "marinara";
        cheese = "normal";
        toppings.clear();
        toppings.add("mushroom");
        toppings.add("pepper");
        toppings.add("pepperoni");
        seasoning = true;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getCrust() {
        return crust;
    }

    public void setCrust(String crust) {
        this.crust = crust;
    }

    public String getSauce() {
        return sauce;
    }

    public void setSauce(String sauce) {
        this.sauce = sauce;
    }

    public String getCheese() {
        return cheese;
    }

    public void setCheese(String cheese) {
        this.cheese = cheese;
    }

    public ArrayList<String> getToppings() {
        return toppings;
    }

    public void addTopping(String topping) {
        if (!toppings.contains(topping)) {
            toppings.add(topping);
        }
    }

    public void removeTopping(String topping) {
        toppings.remove(topping);
    }

    public boolean isSeasoned() {
        return seasoning;
    }

    public void setSeasoning(boolean seasoning) {
        this.seasoning = seasoning;
    }

    public ArrayList<ImageView> getImages() {
        // create a new arraylist of IVs to be returned
        ArrayList<ImageView> imageViews = new ArrayList<>();
        // add the crust first by calling loadImage method with the getCrustPath method
        imageViews.add(loadImage(getCrustPath()));
        // add sauce next
        imageViews.add(loadImage(getSaucePath()));
        // add cheese next and first time called pass false
        imageViews.add(loadImage(getCheesePath(false)));
        if (cheese.equals("extra")) { // if cheese is extra call it again with true and this will give us another layer
            imageViews.add(loadImage(getCheesePath(true)));
        }
        for (String t : toppings) { // for each topping add it by passing the string
            imageViews.add(loadImage(getToppingPath(t)));
        }
        imageViews.add(loadImage(getSeasonedPath()));
        return imageViews;
    }

    public ImageView loadImage(String path) {
        // create new iv
        ImageView iv = new ImageView();
        // create new image with path requested
        Image i = new Image("file:" + path);
        // set the IV to that image
        iv.setImage(i);
        // return the IV
        return iv;
    }

    // returns the path to the image based on the attribute's value for all get____Path functions
    public String getCrustPath() {
        return switch (crust) {
            case "chicago" -> "src/assets/images/crust_chicago.png";
            case "nyc" -> "src/assets/images/crust_nyc.png";
            default -> "";
        };
    }

    public String getCheesePath(Boolean cheese2) {
        if (cheese2) {
            return "src/assets/images/cheese_normal.png";
        }
        return switch (cheese) {
            case "normal" -> "src/assets/images/cheese_normal.png";
            case "extra" -> "src/assets/images/cheese_extra.png";
            case "none" -> "";
            default -> null;
        };
    }

    public String getToppingPath(String topping) {
        if (toppings.contains(topping)) { // we can make this easier by using the topping in the path
            return "src/assets/images/topping_" + topping + ".png"; // I could have replaced some of these switch case statements with this, but I did them before
        } // Sauce below could be just returning src/assets/images/sauce_ + sauce + .png if it isn't none etc
        return "";
    }

    public String getSaucePath() {
        return switch (sauce) {
            case "marinara" -> "src/assets/images/sauce_marinara.png";
            case "chipotle" -> "src/assets/images/sauce_chipotle.png";
            case "alfredo" -> "src/assets/images/sauce_alfredo.png";
            case "barbeque" -> "src/assets/images/sauce_barbeque.png";
            default -> "";
        };
    }

    public String getSeasonedPath() {
        if (seasoning) {
            return "src/assets/images/seasoning.png";
        }
        return "";
    }

    // default override for toString if the need to print attributes arises
    @Override
    public String toString() {
        return "Pizza{" +
                "size='" + size + '\'' +
                ", sauce='" + sauce + '\'' +
                ", crust='" + crust + '\'' +
                ", cheese='" + cheese + '\'' +
                ", toppings=" + toppings +
                ", seasoning=" + seasoning +
                '}';
    }
}
